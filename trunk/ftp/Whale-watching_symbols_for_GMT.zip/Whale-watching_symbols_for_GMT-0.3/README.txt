GMT symbols for Whale-watchers and marine biologists
-----------------------------------------------------

What's this?
------------
This is a collection of extra symbols for the Generic Mapping Tools (GMT) software that can
be of interest mainly to whale-watchers or whale researchers. With this, you can show your 
data in a map created with GMT as fine and detailed marine mammal's icons instead the 
usual circles or squares. GMT is a very complete GIS software so you could add also 
bathymetric and coastal lines, the situation of the main cities and ports in your area, 
or other useful data like planckton concentration or water temperatures in your map.
 
Currently comprises symbols for 8 species of Baleen Whales, 16 of Toothed Whales, 
2 sp of seals and 4 more for "unidentified" seals, beaked whales, dolphins or whales. 
Several versions (low/normal/high) of most symbols are also available, and you can 
change easily between color or gray symbols in 57 of the 99 symbols provided, therefore
 you can choose really between more than 150 different symbols.  

The main upstream authors of GMT are: Paul Wessel <wessel@soest.hawaii.edu> and 
Walter Smith <wsmith@nodc.noaa.gov>. Please don't bother them for questions relative
 to this collection or ask them for new symbols, instead e-mail me, the author of the 
symbols: Pablo Valdés <marine.biol@arsystel.com> (Spanish preferred, but you can use also
English or French). In the future I hope to create gradually more symbols for other species. 
I greatly appreciate your suggestions and feedback.

These symbols are freely available under a GNU Library General Public Licence (version 2, 
or later).

 
How to use the symbols?
-----------------------
First of all, you need to have a functional version of GMT installed in your computer. 
These symbols work fine for me using a GMT version 4.2.0-1. 

1: Before to start, think in the type of map you want to obtain and prepare your data. 
  If you want to create a 2D map (most common situation) you need psxy, if you want a 3D
  map you should use psxyz instead. Think also in how many different symbols you want to 
  show in each individual map. You should have at least a different .xy file for each
  species that you want to show. You could want also to show separately males and females 
  or adults/youngs/calfs. In this case, you will either need to give a different size to each 
  group or place the data for each group in a different .xy (or .xyz) file and provide 
  different symbols. 
 
 A valid input datafile.xy is simply a text file containing several lines like this:

#common dolphin data, file: cdolphin.xy
#longitude latitude (symbolsize) (symboltype) (...others)
-5:40:44   30:30:01  0.10	 k
 6:45.70   -43       0.12	 k
 355.707   42.7543   0.17	 k
            ...

 Psxy can deal with several lon/lat formats. All of this are accepted.
 The symbolsize field is optional, but if not provided you must specify a common size 
 (used for all observations in this file) in the script with -Sksymbolname/simbolsize  
 
 The symboltype field is also optional, k means custom symbol. Currently I can't pass 
 different symbols to psxy in the same file (I need split first the file) 
 and must provide a unique symbolname in the script for all lines, so the interest 
 of having this field is reduced. Probably I'm missing something. You can also add other fields
 like font, angle, position or a last field with a short remembering note in a text line, they
 are ignored by psxy but you could pass it to pstext.

2: Take a look at the pics (.png) and choose the symbols that you want. No installation needed, 
   simply browse the directory symbols and copy the files with extension .def having the same 
   name as the desired pic to your working directory. This is the list of symbols available:

English name (scientific name) 
        - symbols available
-------------------------------
Cetacea
  Toothed Whales, SubO. Odontoceti
     1 Common dolphin (Delphinus delphis) 
        - ddelphis_low.def  
        - ddelphis_midlow.def
        - ddelphis.def
        - ddelphis_midhigh.def
        - ddelphis_high.def

     2 Stripped dolphin (Stenella coeruleoalba) 
        - stripped_low.def, stripped.def, stripped_high.def

     3 Bottlenose dolphin (Tursiops truncatus) 
        - bottlenose_low.def, bottlenose.def, bottlenose_high.def

     4 Atlantic White-sided dolphin (Lagenorhynchus acutus) 
        - atlanticwhitesided_low.def, atlanticwhitesided.def, atlanticwhitesided_high.def

     5 Killer whale (Orcinus orca) 
        - killerwhale_low.def, killerwhale.def, killerwhale_high.def

     6 Risso's dolphin (Grampus griseus) 
        - rissosdolphin_low.def, rissosdolphin.def, rissosdolphin_high.def

     7 Short-Finned Pilot whale (Globicephala macrorhynchus) 
        - shortfinnnedpilotwhale_low.def,  shortfinnnedpilotwhale.def
        - shortfinnnedpilotwhale_low.def

     8 Long-Finned Pilot whale (Globicephala melaena) 
        - longfinnedpilotwhale_low.def, longfinnedpilotwhale.def
        - longfinnedpilotwhale_low.def

     9 Southern Rightwhale Dolphin (Lagenodelphis peronii)
	- srightwhaledolphin_low.def, srightwhaledolphin.def
	- srightwhaledolphin_high.def

     10 Common porpoise (Phocoena phocoena) 
        - commonporpoise_low.def, commonporpoise.def, commonporpoise_high.def

     11	Burmeister's porpoise (Phocoena spinipinnis)
        - burmeistersporpoise_low.def, burmeistersporpoise.def, burmeistersporpoise_high.def

     12 Spectacled porpoise (Australophocaena dioptrica)
        - spectacledporpoise_low.def, spectacledporpoise.def, spectacledporpoise_high.def
	
     13 Beluga (Delphinaterus leucas) 
        - beluga_low.def,  beluga.def,  beluga_high.def

     14 Cuvier's beaked whale (Ziphius cavirostris) 
        - cuviersbeaked_low.def,  cuviersbeaked.def, cuviersbeaked_high.def

     15 Unidentified beaked whale (Mesoplodon spp.) 
        - unidentifiedbeakedwhale_low.def, unidentifiedbeakedwhale.def, 
          unidentifiedbeakedwhale_high.def

     16 Sperm whale (Physeter macrocephalus) 
        - spermwhale_low.def, spermwhale.def, spermwhale_high.def
	- spermwhaletail_low.def, spermwhaletail.def, spermwhaletail_high.def

     17 Pygmy sperm whale (Kogia breviceps)
        - pigmyspermwhale_low.def, pigmyspermwhale.def, pigmyspermwhale_high.def

     18 A dolphin (gen. unknown)
       	- unidentifieddolphin_low.def, unidentifieddolphin.def, unidentifieddolphin_high.def

  Baleen Whales, SubO. Misticeti:
     19 Minke whale (Balaenoptera acutorostrata)
     	- minkewhale.def, minkewhale_low.def, minkewhale_high.def

     20 Fin Whale (Balaenoptera physalus)
        - finwhale.def,  finwhale_low.def,  finwhale_high.def

     21	Sei Whale (Balaenoptera borealis)
        - seiwhale_low.def,  seiwhale.def,  seiwhale_high.def

     22 Humpback Whale (Megaptera novaeangliae)
     	- humpbacktail_one_low.def,  humpbacktail_one.def
	- humpbacktail_two_low.def,  humpbacktail_two.def
	- jumpback_low.def (yes, with j, look at the pic ;-))
	- jumpback.def, jumpback_high.def

     23 Gray Whale (Eschrichtius robustus)
        - graywhale_low.def,  graywhale.def,  graywhale_high.def

     24	Right Whales (Eubalaena glacialis, Eubalaena australis)
        - southernrightwhale_low.def, southernrightwhale.def, southernrightwhale_high.def
        - northernrightwhale_low.def, northernrightwhale.def, northernrightwhale_high.def

     25 A whale (unknown species)
       	- unidentifiedwhale_low.def, unidentifiedwhale.def, unidentifiedwhale_high.def

Pinnipedia, (Seals):
     26 Harp seal (Phoca groenlandica)
        - harpseal_low.def,   harpseal.def,   harpseal_high.def

     27 Hooded seal (Cystophora cristata)
        - hoodedseal_low.def,  hoodedseal.def,  hoodedseal_high.def

     28 A Seal (appliable to several species)
     	- seal_low.def,  seal.def,  seal_high.def

3: Call them including the corresponding pxsy or psxyz lines in a GMT script like this: 

#!/bin/bash
  pscoast -JM20c -R-10/6/33/36 -K -W0.5pt/0 -P -Gblack > myfile.ps
  psxy cdolphin.xy -Skcommondolphin/ -JM20c -R-10/6/33/36 -P -K -O >> myfile.ps
  psxy bottlenose_dolphin.xy -Skbottlenose_high/0.5 -K -O ...etc >> myfile.ps
  psxy killerwhale_data.xy   -Skkillerwhale_low/0.5 -O ...etc >> myfile.ps

 In our examples we will place all the .xy and .def files in our working directory, 
 but you can find more convenient to move them to several subdirectories named, for
 instance, data and symbols:

  psxy data/killer_whale.xy -Sksymbols/Cetacea/killerwhale/0.5 -O ...etc >> myfile.ps

 In this case, please read also the points 1.2-1.3 of the file FAQ.txt
  
4: Run the bash script, print/open the output postscript file myfile.ps, and enjoy. 
  Alternatively if you had installed ps2pdf and xpdf you can convert it first to pdf 
  adding something like this at the end of the script:

   ps2pdf myfile.ps myfile.pdf && xpdf myfile.pdf

Still confused? Please take a look at the file FAQ.txt and at the documentation 
provided with GMT.
